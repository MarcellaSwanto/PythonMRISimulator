def DoGradChk():
    from sympy import Symbol, Derivative

    ExecFlag = 1
    GradTolerance = np.abs(VCtl['MaxGrad']*0.01) #Need to test if this is the correct usage...
    SRTolerance = np.abs(VCtl['MaxSlewRate']*0.01)

    #Check Gz
    Flags = VSeq['flasLine'][1,:]
    t = #complete this later

    dt = sp.misc.derivative()


    return ExecFlag
