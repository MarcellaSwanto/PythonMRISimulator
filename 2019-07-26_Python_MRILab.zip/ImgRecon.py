# from DoPostScan import VCtl
# from DoPostScan import VImg
# from DoPostScan import VObj
# from DoPostScan import VCoi
# from DoPostScan import VSig
import numpy as np
def ImgRecon():
    ExecFlag = 1
    TmpImg = VImg
    VImg = []   #clear VImg

    #Normal Cartesian
    VCtl["TEPerTR"]=1
    SX=reshape(VSig["Sx"], VCtl["ResFreq"] * VCtl["TEPerTR"],VCtl["ResPhase"],VCtl["SliceNum"],VCoi["RxCoilNum"],VObj["TypeNum"])  #matlab col priority
    SY=reshape(VSig["Sy"], VCtl["ResFreq"] * VCtl["TEPerTR"],VCtl["ResPhase"],VCtl["SliceNum"],VCoi["RxCoilNum"],VObj["TypeNum"])
    SX=sum(SX, 4)   #sum signal from all spin types
    SY=sum(SY, 4)

    #Cartesian k-space recon
    N=VCtl["TEPerTR"]
    for e in range(N):
        Sx=SX[(e-1)*VCtl["ResFreq"] + range(1,n+1,e*VCtl["ResFreq"]), :,:,:]
        Sy=SY[(e-1)*VCtl["ResFreq"] + range(1,n+1,e*VCtl["ResFreq"]), :,:,:]
        #default -KxMax -> KxMax, -KyMax -> KyMax
        #remove the most positive Kx point for making even number of Kx sample points (used for Matlab default fft)
        Sx[Sx[-1],:,:,:]=[]
        Sy[Sx[-1],:,:,:]=[]
        VCtl["ResFreq"]=101 #hardcoded
        ResFreq = VCtl["ResFreq"] - 1
        # skipped the if statement here - not used in GUI-less matlab version
        #for VCtl["FreqDir"]="A/P"
        Sx=np.transpose(Sx,[2, 1, 3, 4])
        Sy=np.transpose(Sy,[2, 1, 3, 4])
        #else
        # Sx=np.transpose(Sx,[1,2,3,4])
        # Sy=np.transpose(Sy,[1,2,3,4])
        S=complex(Sx,Sy)
        VCoi["RxCoilNum"]=1
        for k in VCoi["RxCoilNum"]:
            VImg["Real"][:,:,:,i,e]=np.real(np.fft.fftshift(np.fft.ifftn(np.fft.fftshift(S[:,:,:,i]))))
            VImg["Imag"][:,:,:,i,e]=np.imag(np.fft.fftshift(np.fft.ifftn(np.fftfftshift(S[:,:,:,i]))))
            VImg["Mag"][:,:,:,i,e]=np.absolute(VImg["Real"][:,:,:,i,e]+1j*VImg["Imag"][:,:,:,i,e])
            VImg["Phase"][:,:,:,i,e]=np.angle(VImg["Real"][:,:,:,i,e]+1j*VImg["Imag"][:,:,:,i,e])
    return ExecFlag
