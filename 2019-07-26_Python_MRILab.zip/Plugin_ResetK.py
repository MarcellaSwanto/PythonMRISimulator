# from DoExtPlugin import VVar

#important data type conversion, has to be done!!!!
def Plugin_ResetK():
    VVar["Kz"] = double(0)
    VVar["Ky"] = double(0)
    VVar["Kx"] = double(0)
