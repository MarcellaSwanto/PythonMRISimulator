def Readhdf5():
    import h5py
    import numpy
    import matplotlib.pyplot as plt
    import matplotlib.image as mpimg

    f = h5py.File('myfile.h5', 'r') # Open the file for reading
    list(f.keys())  # This should show us what datasets are stored in the file

    Rho = f['Rho'][:] # Cool, no? This gets the data from the file for Rho
    #Rho_img=Rho[:,:,50] # This gets one slice

    T2 = f['T2'] # It seems we don't need that [:] thing....
    #T2_img = T2[:,:,50]

    T1 = f['T1']
    #T1_img = T1[:,:,50]

    T2Star = f['T2Star']
   # T2Star_img = T2Star[:,:,50]

    MassDen = f['MassDen']
    #MassDen_img = MassDen[:,:,50]

    Gyro = f['Gyro']

    dictionary={"Rho" : Rho,"T2" : T2,"T1" : T1,"MassDen" : MassDen,"T2Star" : T2Star, 'Gyro' : Gyro}
    return dictionary
