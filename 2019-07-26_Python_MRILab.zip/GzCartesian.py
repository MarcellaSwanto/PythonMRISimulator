def GzCartesian(p, VObj, VCtl, VVar):

    import numpy as np
    import math
    from StdTrap import StdTrap
    t1Start = p['t1Start']
    t1End = p['t1End']
    t2Start = p['t2Start']
    t2End = p['t2End']
    tRamp = p['tRamp']
    Gz1Sign = p['Gz1Sign']
    Gz2Sign = p['Gz2Sign']

    Duplicates = np.maximum(1,p['Duplicates'])
    DupSpacing = np.maximum(0, p['DupSpacing'])

    #Phase encoding
    GzdG = np.divide(1,np.divide(VObj['Gyro'],(2*math.pi)*(t1End-t1Start)*(VCtl['FOVSlice'])))
    tempDict = StdTrap(t1Start-tRamp,t1End+tRamp,t1Start,t1End,(VVar['SliceCount']-np.floor(VCtl['SliceNum']/2)-1)*GzdG*Gz1Sign,2,2,2)
    GAmp1 = tempDict['Grad']
    GTime1 = tempDict['t']

    #Rephasing
    GzdG = np.divide(1, np.divide(VObj['Gyro'],(2*math.pi)*(t2End-t2Start)*(VCtl['FOVSlice'])))
    tempDict = StdTrap(t2Start-tRamp,t2End+tRamp,t2Start,t2End,(VVar['SliceCount']-np.floor(VCtl['SliceNum']/2)-1)*GzdG*Gz2Sign,2,2,2)
    GAmp2 = tempDict['Grad']
    GTime2 = tempDict['t']

    GAmp = GAmp1
    GTime = GTime1

    if Gz2Sign != 0:
        GAmp = np.concatenate((GAmp, GAmp2), axis = None)
        GTime = np.concatenate((GTime, GTime2), axis = None)

    GTime, m, n = np.unique(GTime, return_index = True, return_inverse = True)
    GAmp = GAmp[m]
    dict = {'GAmp':GAmp, 'GTime':GTime}
    return dict
