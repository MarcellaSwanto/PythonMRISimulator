def PulseGen(VVar, VCtl, VObj):
    import numpy as np
    from PSD_GRE3D import PSD_GRE3D

    VCtl['PlotSeq'] = 0
    TmpTR = 10
    TmpFlipAng = VCtl['FlipAng']

    #Pulse and gradient signal generation
    DP = 0
    VVar['SliceCount'] = 0
    VVar['PhaseCount'] = 0
    VVar['TRCount'] = 0
    s = 1
    j = 0
    #PulseGen Loop
    while s<=VCtl['SecondPhNum']:
        VVar['SliceCount'] = s
        while j<VCtl['FirstPhNum']:
            VVar['PhaseCount'] = j
            VVar['TRCount'] = VVar['TRCount']+1

            tmpDict = PSD_GRE3D(VCtl, VVar, VObj)
            rfAmp = tmpDict['rfAmp']
            rfPhase = tmpDict['rfPhase']
            rfFreq = tmpDict['rfFreq']
            rfCoil = tmpDict['rfCoil']
            GzAmp = tmpDict['GzAmp']
            GyAmp = tmpDict['GyAmp']
            GxAmp = tmpDict['GxAmp']
            ADC = tmpDict['ADC']
            Ext = tmpDict['Ext']
            uts = tmpDict['uts']
            ts = tmpDict['ts']
            flags = tmpDict['flags']

            if VVar['TRCount'] ==1 and DP ==0:
                rfAmpLine = rfAmp
                rfPhaseLine = rfPhase
                rfFreqLine = rfFreq
                rfCoilLine = rfCoil
                GzAmpLine = GzAmp
                GyAmpLine = GyAmp
                GxAmpLine = GxAmp
                ADCLine = ADC
                ExtLine = Ext
                utsLine = uts
                tsLine = ts
                flagsLine = flags
                templistrfAmp = rfAmp[0].tolist()
                templistrfPhase = rfPhase[0].tolist()
                templistrfFreq = rfFreq[0].tolist()
                templistrfCoil = rfCoil[0].tolist()
                templistGz = GzAmp[0].tolist()
                templistGy = GyAmp[0].tolist()
                templistGx = GxAmp[0].tolist()
                templistADC = ADC[0].tolist()
                templistExt = Ext[0].tolist()
                templistuts = uts[0].tolist()
                templistts = ts[0].tolist()
                templistflags = []

                for i in range(0,6):
                    templistflags = templistflags + flags[i].tolist()
            else:

                for i in range(0,len(rfAmp[0])):
                    templistrfAmp.append(rfAmp[0][i])
                rfAmpLine = np.array(templistrfAmp)

                # rfPhaseLine[len(rfPhaseLine):len(rfPhaseLine)-1+len(rfPhase)] = rfPhase
                for i in range(0,len(rfPhase[0])):
                    templistrfPhase.append(rfPhase[0][i])
                rfPhaseLine = np.array(templistrfPhase)

                # rfFreqLine[len(rfFreqLine):len(rfFreqLine)-1+len(rfFreq)] = rfFreq
                for i in range(0,len(rfFreq[0])):
                    templistrfFreq.append(rfFreq[0][i])
                rfFreqLine = np.array(templistrfFreq)

                # rfCoilLine[len(rfCoilLine):len(rfCoilLine)-1+len(rfCoil)] = rfCoil
                for i in range(0,len(rfCoil[0])):
                    templistrfCoil.append(rfCoil[0][i])
                rfCoilLine = np.array(templistrfCoil)

                # GzAmpLine[len(GzAmpLine):len(GzAmpLine)-1+len(GzAmp)] = GzAmp
                for i in range(0, len(GzAmp[0])):
                    templistGz.append(GzAmp[0][i])
                GzAmpLine = np.array(templistGz)

                # GyAmpLine[len(GyAmpLine):len(GyAmpLine)-1+len(GyAmp)] = GyAmp
                for i in range(0,len(GyAmp[0])):
                    templistGy.append(GyAmp[0][i])
                GyAmpLine = np.array(templistGy)

                # GxAmpLine[len(GxAmpLine):len(GxAmpLine)-1+len(GxAmp)] = GxAmp
                for i in range(0,len(GxAmp[0])):
                    templistGx.append(GxAmp[0][i])
                GxAmpLine = np.array(templistGx)

                # ADCLine[len(ADCLine[0]):len(ADCLine[0])-1+len(ADC[0])] = ADC[0]
                for i in range(0,len(ADC[0])):
                    templistADC.append(ADC[0][i])
                ADCLine = np.array(templistADC)

                # ExtLine[len(ExtLine):len(ExtLine)-1+len(Ext)] = Ext
                for i in range(0,len(Ext[0])):
                    templistExt.append(Ext[0][i])
                ExtLine = np.array(templistExt)

                # utsLine[len(utsLine):len(utsLine)-1+len(uts)] = uts
                for i in range(0,len(uts[0])):
                    templistuts.append(uts[0][i])
                utsLine = np.array(templistuts)

                # tsLine[len(tsLine):len(tsLine)-1+len(ts)] = ts
                for i in range(0,len(ts[0])):
                    templistts.append(ts[0][i])
                tsLine = np.array(templistts)

                # flagsLine[len(flagsLine):len(flagsLine)-1+len(flags)] = flags
                for x in range(0,6):
                    for i in range(0,181):
                        templistflags.append(flags[x][i])

            j = j+1
        if s==1 and j==1 and DP==1:
            continue
        j = 1
        s = s+1
    flagsLine = np.array(templistflags)
    flagsLine = flagsLine.reshape(6,14480)
    
    VVar['SliceCount'] = 0
    VVar['PhaseCount'] = 0
    VVar['TRCount'] = 0

    VSeq = {}
    VSeq['rfAmpLine'] = rfAmpLine
    VSeq['rfPhaseLine'] = rfPhaseLine
    VSeq['rfFreqLine'] = rfFreqLine
    VSeq['GzAmpLine'] = GzAmpLine
    VSeq['GyAmpLine'] = GyAmpLine
    VSeq['GxAmpLine'] = GxAmpLine
    VSeq['ADCLine'] = ADCLine
    VSeq['ExtLine'] = ExtLine
    VSeq['utsLine'] = utsLine
    VSeq['tsLine'] = tsLine
    VSeq['flagsLine'] = flagsLine

    VSeq['rfCoilLine'] = np.ones(rfCoilLine.shape)# force to convert rfCoilLine
    #to 1 for single Tx - simplified as multi-transmit will always be off

    #Did not include this
    # #Do grad amplitude and slew rate check
    # ExecFlag = DoGradChk
    # if ExecFlag ==0:
    #     VSeq = []
    #     print("Gradient check failed!")
    #
    # #Do update rate check
    # ExecFlag = DoUpdRateChk
    # if ExecFlag ==0:
    #     VSeq = []
    #     print("Update rate check failed!")
    dict={'VVar': VVar, 'VCtl': VCtl, 'VSeq' : VSeq}
    return dict
