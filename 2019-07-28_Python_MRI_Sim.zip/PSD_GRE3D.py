import numpy as np
#returns psd_gre3d dictionary containing rfAmp,rfPhase,rfFreq,rfCoil,GzAmp,GyAmp,GxAmp,ADC,Ext,uts,ts,flags
def PSD_GRE3D(VCtl, VVar, VObj):
    from rfSinc import rfSinc
    from ADCCartesian import ADCCartesian
    from GxCartesian import GxCartesian
    from GzCartesian import GzCartesian
    from GyCartesian import GyCartesian
    from ExtBit import ExtBit
    CV1=10e-3
    CV10=0
    CV11=0
    CV12=0
    CV13=0
    CV14=0
    CV2=20e-3
    CV3=0
    CV4=0
    CV5=0
    CV6=0
    CV7=0
    CV8=0
    CV9=0
    rfAmpAll=[]
    rfPhaseAll=[]
    rfFreqAll=[]
    rfCoilAll=[]
    GzAmpAll=[]
    GyAmpAll=[]
    GxAmpAll=[]
    ADCAll=[]
    ExtAll=[]
    rfTimeAll=[]
    GzTimeAll=[]
    GyTimeAll=[]
    GxTimeAll=[]
    ADCTimeAll=[]
    ExtTimeAll=[]
    SEtAll=[]
    uts=[]
    ts=[]
    flags=[]
    if VCtl['PlotSeq'] == 1: #it is 0
        rfAmp=[]
        rfPhase=[]
        rfFreq=[]
        rfCoil=[]
        GzAmp=[]
        GyAmp=[]
        GxAmp=[]
        ADC=[]
        Ext=[]
        Freq=1
        Notes ='regular TR section'
        AttributeOpt=['on','off']
        Switch=AttributeOpt[0]
        TREnd=Inf
        TRStart=1
        tE=VCtl['TR']
        tS=0
        if VVar['TRCount']<TRStart or VVar['TRCount']>TREnd or mod(VVar['TRCount']-TRStart,Freq)!=0 or Switch=='off':
            pass
        else:
            ts = [ts, tS, tE]
        ts = [0, npamax(ts)-npamin(ts)]
        return
    #==============Pulses 1==============
    rfAmp=[]
    rfPhase=[]
    rfFreq=[]
    rfCoil=[]
    GzAmp=[]
    GyAmp=[]
    GxAmp=[]
    ADC=[]
    Ext=[]
    rfTime=[]
    GzTime=[]
    GyTime=[]
    GxTime=[]
    ADCTime=[]
    ExtTime=[]
    Freq=1
    Notes='regular TR section'
    AttributeOpt=['on','off']
    Switch=AttributeOpt[0]
    TREnd=np.inf
    TRStart=1
    tE=VCtl['TR']
    tS=0
    #    --------------------
    AttributeOpt=['on','off']
    p = {'AnchorTE':AttributeOpt[0]}
    AttributeOpt=['Non','Hamming','Hanning']
    p['Apod']=AttributeOpt[0]
    p['CoilID']=1
    p['DupSpacing']=0
    p['Duplicates']=1
    p['FA']=VCtl['FlipAng']
    p['Notes']='excitation rf'
    AttributeOpt=['on','off']
    p['Switch']=AttributeOpt[0]
    p['TBP']=4
    p['dt']=20e-6
    p['rfFreq']=0
    p['rfPhase']=0
    p['tEnd']=1e-3
    p['tStart']=0
    if p['Switch']=='on':
        if p['AnchorTE']=='on':
            #it seems to always be 'Middle'
                if VCtl['TEAnchor']=='Start':
                    VCtl['TEAnchorTime']=p['tStart']
                if VCtl['TEAnchor']=='Middle':
                    VCtl['TEAnchorTime']=(p['tStart']+p['tEnd'])/2
                if VCtl['TEAnchor']=='End':
                    VCtl['TEAnchorTime']=p['tEnd']
        tempDict=rfSinc(p, VObj)
        rfAmp1 = tempDict['rfAmp']
        rfPhase1 = tempDict['rfPhase']
        rfFreq1 = tempDict['rfFreq']
        rfCoil1 = tempDict['rfCoil']
        rfTime1 = tempDict['rfTime']
        if VCtl['MultiTransmit']=='off':
            if VCtl['MasterTxCoil']==rfCoil1[1]:
                rfAmp=[rfAmp, rfAmp1]
                rfPhase=[rfPhase, rfPhase1]
                rfFreq=[rfFreq, rfFreq1]
                rfCoil=[rfCoil, rfCoil1]
                rfTime=[rfTime, rfTime1]
        else:
            rfAmp=[rfAmp, rfAmp1]
            rfPhase=[rfPhase, rfPhase1]
            rfFreq=[rfFreq, rfFreq1]
            rfCoil=[rfCoil, rfCoil1]
            rfTime=[rfTime, rfTime1]
    p={}
    #--------------------
    p['DupSpacing']=0
    p['Duplicates']=1
    p['Gz1Sign']=1
    p['Gz2Sign']=0
    p['Notes']='cartesian phase'
    AttributeOpt=['on','off']
    p['Switch']=AttributeOpt[0]
    p['t1End']=CV2
    p['t1Start']=CV1
    p['t2End']=VCtl['TE']+CV2
    p['t2Start']=VCtl['TE']+CV1
    p['tRamp']=100e-6
    if p['Switch']=='on':
        tempDict=GzCartesian(p, VObj, VCtl, VVar)
        GzAmp1 = tempDict['GAmp']
        GzTime1 = tempDict['GTime']
        GzAmp=[GzAmp, GzAmp1]
        GzTime=[GzTime, GzTime1]
    p={}
    #--------------------
    p['DupSpacing']=0
    p['Duplicates']=1
    p['Gy1Sign']=1
    p['Gy2Sign']=0
    p['Notes']='cartesian phase'
    AttributeOpt=['on','off']
    p['Switch']=AttributeOpt[0]
    p['t1End']=CV2
    p['t1Start']=CV1
    p['t2End']=VCtl['TE']+CV2
    p['t2Start']=VCtl['TE']+CV1
    p['tRamp']=100e-6
    if p['Switch']=='on':
        tempDict = GyCartesian(p, VObj, VCtl, VVar)
        GyAmp1 = tempDict['GAmp']
        GyTime1 = tempDict['GTime']
        GyAmp=[GyAmp, GyAmp1]
        GyTime=[GyTime, GyTime1]
    p={}
    #--------------------
    p['DupSpacing']=0
    p['Duplicates']=1
    p['Gx1Sign']=-1
    p['Gx2Sign']=1
    p['Gx3Sign']=0
    p['Notes']='cartesian frequency'
    AttributeOpt=['on','off']
    p['Switch']=AttributeOpt[0]
    p['t1Start']=CV1
    p['t2Middle']=VCtl['TE']
    p['t3Start']=VCtl['TE']+CV1
    p['tRamp']=100e-6
    if p['Switch']=='on':
        tempDict=GxCartesian(p, VObj, VCtl, VVar)
        GxAmp1 = tempDict['GAmp']
        GxTime1 = tempDict['GTime']
        GxAmp=[GxAmp, GxAmp1]
        GxTime=[GxTime, GxTime1]
    p={}
    #--------------------
    p['DupSpacing']=0
    p['Duplicates']=1
    p['Notes']='cartesian readout'
    AttributeOpt=['on','off']
    p['Switch']=AttributeOpt[0]
    p['tMiddle']=VCtl['TE']
    if p['Switch']=='on':
        tempDict=ADCCartesian(p, VCtl, VObj)
        ADC1 = tempDict['GAmp']
        ADCTime1 = tempDict['GTime']
        ADC=[ADC, ADC1]
        ADCTime=[ADCTime, ADCTime1]
    p={}
    #--------------------
    p['DupSpacing']=0
    p['Duplicates']=1
    p['Ext']=1
    p['Notes']='reset K space location'
    AttributeOpt=['on','off']
    p['Switch']=AttributeOpt[0]
    p['tStart']=CV1/2
    if p['Switch']=='on':
        tempDict=ExtBit(p, VCtl)
        Ext1 = tempDict['Ext']
        ExtTime1 = tempDict['ExtTime']
        Ext=[Ext, Ext1]
        ExtTime=[ExtTime, ExtTime1]
    p={}
    #--------------------
    p['DupSpacing']=0
    p['Duplicates']=1
    p['Ext']=5
    p['Notes']='calculate remaining scan time'
    AttributeOpt=['on','off']
    p['Switch']=AttributeOpt[0]
    p['tStart']=0
    if p['Switch']=='on':
        tempDict=ExtBit(p, VCtl)
        Ext2 = tempDict['Ext']
        ExtTime2 = tempDict['ExtTime']
        Ext=[Ext, Ext2]
        ExtTime=[ExtTime, ExtTime2]
    p={}
    #--------------------
    p['DupSpacing']=0
    p['Duplicates']=1
    p['Ext']=8
    p['Notes']='trigger object motion'
    AttributeOpt=['on','off']
    p['Switch']=AttributeOpt[0]
    p['tStart']=0.1
    if p['Switch']=='on':
        tempDict=ExtBit(p, VCtl)
        Ext3 = tempDict['Ext']
        ExtTime3 = tempDict['ExtTime']
        Ext=[Ext, Ext3]
        ExtTime=[ExtTime, ExtTime3]
    p={}
    #--------------------
    SEt=[tS, tE]

    rfTime = np.concatenate((rfTime[0], rfTime[1]), axis=None)
    #FIrst 2 dummy variables: conditions
    x1=np.less(SEt[1]-SEt[0], rfTime)
    x2=np.less(rfTime,0)
    #The third dummy variable is their logical or
    x3=np.logical_or(x1,x2)
    #Initialization of temporary lists
    newlist_rfAmp = []
    newlist_rfPhase = []
    newlist_rfFreq = []
    newlist_rfCoil = []
    newlist_rfTime = []

    rfAmp = np.concatenate((rfAmp[0], rfAmp[1]), axis=None)
    rfPhase = np.concatenate((rfPhase[0], rfPhase[1]), axis=None)
    rfFreq = np.concatenate((rfFreq[0], rfFreq[1]), axis=None)
    rfCoil = np.concatenate((rfCoil[0], rfCoil[1]), axis=None)

    for i in range(0,len(x3)):
        if x3[i] == False:
            newlist_rfAmp.append(rfAmp[i])
            newlist_rfPhase.append(rfPhase[i])
            newlist_rfFreq.append(rfFreq[i])
            newlist_rfCoil.append(rfCoil[i])
            newlist_rfTime.append(rfTime[i])
    # Updating original variables
    rfAmp = newlist_rfAmp
    rfPhase = newlist_rfPhase
    rfFreq = newlist_rfFreq
    rfCoil = newlist_rfCoil
    rfTime = newlist_rfTime

    # GzAmp[GzTime<0 or GzTime>SEt(1)-SEt(0)] = []
    GzTime = np.concatenate((GzTime[0], GzTime[1]), axis=None)
    GzAmp = np.concatenate((GzAmp[0], GzAmp[1]), axis=None)
    x1=np.greater(GzTime,SEt[1]-SEt[0])
    x2=np.less(GzTime,0)
    x3=np.logical_or(x1,x2)
    newlist_GzAmp = []
    for i in range(0, len(x3)):
        if x3[i]== False:
            newlist_GzAmp.append(GzAmp[i])
    GzAmp = newlist_GzAmp

    # GyAmp[GyTime<0 or GyTime>SEt(1)-SEt(0)] = []
    GyTime = np.concatenate((GyTime[0], GyTime[1]), axis=None)
    GyAmp = np.concatenate((GyAmp[0], GyAmp[1]), axis=None)
    x1=np.greater(GyTime,SEt[1]-SEt[0])
    x2=np.less(GyTime,0)
    x3=np.logical_or(x1,x2)
    newlist_GyAmp = []
    for i in range(0, len(x3)):
        if x3[i]== False:
            newlist_GyAmp.append(GyAmp[i])
    GyAmp = newlist_GyAmp

    # GxAmp[GxTime<0 or GxTime>SEt(1)-SEt(0)] = []
    GxTime = np.concatenate((GxTime[0], GxTime[1]), axis=None)
    GxAmp = np.concatenate((GxAmp[0], GxAmp[1]), axis=None)
    x1=np.greater(GxTime,SEt[1]-SEt[0])
    x2=np.less(GxTime,0)
    x3=np.logical_or(x1,x2)
    newlist_GxAmp = []
    for i in range(0, len(x3)):
        if x3[i]== False:
            newlist_GxAmp.append(GxAmp[i])
    GxAmp = newlist_GxAmp

    # ADC[ADCTime<0 or ADCTime>SEt(1)-SEt(0)] = []
    ADCTime = np.concatenate((ADCTime[0], ADCTime[1]), axis=None)
    ADC = np.concatenate((ADC[0], ADC[1]), axis=None)
    x1=np.greater(ADCTime, SEt[1]-SEt[0])
    x2=np.less(ADCTime, 0)
    x3=np.logical_or(x1,x2)
    newlist_ADC = []
    for i in range(0, len(x3)):
        if x3[i]== False:
            newlist_ADC.append(ADC[i])
    ADC = newlist_ADC

    # Ext[ExtTime<0 or ExtTime>SEt(1)-SEt(0)] = []
    #hardcoded
    ExtTime = np.concatenate((ExtTime[0][0][0],ExtTime[0][0][1],ExtTime[0][1][0],ExtTime[0][1][1],ExtTime[0][1][2], ExtTime[1][0],ExtTime[1][1],ExtTime[1][2]), axis=None)
    Ext = np.concatenate((Ext[0][0][0],Ext[0][0][1],Ext[0][1][0],Ext[0][1][1],Ext[0][1][2], Ext[1][0],Ext[1][1],Ext[1][2]), axis=None)
    x1=np.less(SEt[1]-SEt[0],ExtTime)
    x2=np.less(ExtTime, 0)
    x3=np.logical_or(x1,x2)
    newlist_Ext = []
    for i in range(0, len(x3)):
        if x3[i]== False:
            newlist_Ext.append(Ext[i])
    Ext = newlist_Ext

    # GzTime[GzTime<0 or GzTime>SEt(1)-SEt(0)] = []
    x1=np.greater(GzTime, SEt[1]-SEt[0])
    x2=np.less(GzTime, 0)
    x3=np.logical_or(x1,x2)
    newlist_GzTime = []
    for i in range(0, len(x3)):
        if x3[i]== False:
            newlist_GzTime.append(GzTime[i])
    GzTime = newlist_GzTime

    # GyTime[GyTime<0 or GyTime>SEt(1)-SEt(0)] = []
    x1=np.greater(GyTime, SEt[1]-SEt[0])
    x2=np.less(GyTime, 0)
    x3=np.logical_or(x1,x2)
    newlist_GyTime = []
    for i in range(0, len(x3)):
        if x3[i]== False:
            newlist_GyTime.append(GyTime[i])
    GyTime = newlist_GyTime

    # GxTime[GxTime<0 or GxTime>SEt(1)-SEt(0)] = []
    x1=np.greater(GxTime, SEt[1]-SEt[0])
    x2=np.less(GxTime, 0)
    x3=np.logical_or(x1,x2)
    newlist_GxTime = []
    for i in range(0, len(x3)):
        if x3[i]== False:
            newlist_GxTime.append(GxTime[i])
    GxTime = newlist_GxTime

    # ADCTime[ADCTime<0 or ADCTime>SEt(1)-SEt(0)] = []
    x1=np.greater(ADCTime, SEt[1]-SEt[0])
    x2=np.less(ADCTime, 0)
    x3=np.logical_or(x1,x2)
    newlist_ADCTime = []
    for i in range(0, len(x3)):
        if x3[i]== False:
            newlist_ADCTime.append(ADCTime[i])
    ADCTime = newlist_ADCTime

    # ExtTime[ExtTime<0 or ExtTime>SEt(1)-SEt(0)] = []
    x1=np.greater(ExtTime, SEt[1]-SEt[0])
    x2=np.less(ExtTime, 0)
    x3=np.logical_or(x1,x2)
    newlist_ExtTime = []
    for i in range(0, len(x3)):
        if x3[i]== False:
            newlist_ExtTime.append(ExtTime[i])
    ExtTime = newlist_ExtTime

    # rfAmp[np.absolute(rfAmp)<eps] = 0
    rfAmpAbs=np.absolute(rfAmp)
    eps = np.spacing(1)
    rfAmp1=np.greater(eps, rfAmpAbs)
    newlist_rfAmp1 = []
    for i in range(0, len(rfAmp1)):
        if rfAmp1[1] == True:
            newlist_Ext.append(0)
        else:
            newlist_rfAmp1.append(rfAmp[i])
    rfAmp = newlist_rfAmp1

    # Adding SEt[0] element-wise
    rfTime = [x + SEt[0] for x in rfTime]
    GzTime = [x + SEt[0] for x in GzTime]
    GyTime = [x + SEt[0] for x in GyTime]
    GxTime = [x + SEt[0] for x in GxTime]
    ADCTime = [x + SEt[0] for x in ADCTime]
    ExtTime = [x + SEt[0] for x in ExtTime]
    #Usually, "---All" variables are empty
    rfAmpAll=[rfAmpAll, rfAmp]
    rfAmpAll=np.concatenate((rfAmpAll[0], rfAmpAll[1]), axis=None)
    rfPhaseAll=[rfPhaseAll, rfPhase]
    rfPhaseAll=np.concatenate((rfPhaseAll[0], rfPhaseAll[1]), axis=None)
    rfFreqAll=[rfFreqAll, rfFreq]
    rfFreqAll=np.concatenate((rfFreqAll[0], rfFreqAll[1]), axis=None)
    rfCoilAll=[rfCoilAll, rfCoil]
    rfCoilAll=np.concatenate((rfCoilAll[0], rfCoilAll[1]), axis=None)
    GzAmpAll=[GzAmpAll, GzAmp]
    GzAmpAll=np.concatenate((GzAmpAll[0], GzAmpAll[1]), axis=None)
    GyAmpAll=[GyAmpAll, GyAmp]
    GyAmpAll=np.concatenate((GyAmpAll[0], GyAmpAll[1]), axis=None)
    GxAmpAll=[GxAmpAll, GxAmp]
    GxAmpAll=np.concatenate((GxAmpAll[0], GxAmpAll[1]), axis=None)
    ADCAll=[ADCAll, ADC]
    ADCAll=np.concatenate((ADCAll[0], ADCAll[1]), axis=None)
    ExtAll=[ExtAll, Ext]
    ExtAll=np.concatenate((ExtAll[0], ExtAll[1]), axis=None)
    rfTimeAll=[rfTimeAll, rfTime]
    GzTimeAll=[GzTimeAll, GzTime]
    GyTimeAll=[GyTimeAll, GyTime]
    GxTimeAll=[GxTimeAll, GxTime]
    ADCTimeAll=[ADCTimeAll, ADCTime]
    ExtTimeAll=[ExtTimeAll, ExtTime]
    SEtAll=[SEtAll, SEt]
    SEtAll=np.concatenate((SEtAll[0], SEtAll[1]), axis=None)
    rfTimeAll=np.concatenate((rfTimeAll[0], rfTimeAll[1]), axis=None)
    GzTimeAll=np.concatenate((GzTimeAll[0], GzTimeAll[1]), axis=None)
    GxTimeAll=np.concatenate((GxTimeAll[0], GxTimeAll[1]), axis=None)
    GyTimeAll=np.concatenate((GyTimeAll[0], GyTimeAll[1]), axis=None)
    ADCTimeAll=np.concatenate((ADCTimeAll[0], ADCTimeAll[1]), axis=None)
    ExtTimeAll=np.concatenate((ExtTimeAll[0], ExtTimeAll[1]), axis=None)

    SEflag=np.tile([[0], [0], [0], [0], [0], [0]],[1, 2])
    rfflag=np.tile([[1], [0], [0], [0], [0], [0]],[1, len(rfTimeAll)])
    Gzflag=np.tile([[0], [1], [0], [0], [0], [0]],[1, len(GzTimeAll)])
    Gyflag=np.tile([[0], [0], [1], [0], [0], [0]],[1, len(GyTimeAll)])
    Gxflag=np.tile([[0], [0], [0], [1], [0], [0]],[1, len(GxTimeAll)])
    ADCflag=np.tile([[0], [0], [0], [0], [1], [0]],[1, len(ADCTimeAll)])
    Extflag=np.tile([[0], [0], [0], [0], [0], [1]],[1, len(ExtTimeAll)])

    ts=np.concatenate((np.amin(SEtAll), np.amax(SEtAll), rfTimeAll, GzTimeAll, GyTimeAll, GxTimeAll, ADCTimeAll, ExtTimeAll), axis=None)
    # ts=(np.concatenate(np.amin(SEtAll), np.amax(SEtAll))).tolist() + rfTimeAll.tolist()+ GzTimeAll.tolist()+ GyTimeAll.tolist()+ GxTimeAll.tolist()+ ADCTimeAll.tolist()+ ExtTimeAll.tolist()

    ts = [x - np.amin(SEtAll) for x in ts]  #minimum of SEtAl is 0, maximum is 10
    flags=np.array(np.concatenate((SEflag, rfflag, Gzflag, Gyflag, Gxflag, ADCflag, Extflag),axis=None)) #6x181 array

    # [ts,ind]=sort(ts)
    ts=np.array(ts)
    ts=ts.reshape(1,len(ts))
    ind=np.argsort(ts)
    # ts=ts[ind]
    ts=np.sort(ts)
    uts=np.unique(ts) #set both to false
    uts=uts.reshape(1,len(uts))

    flags=(flags.reshape(6,181))
    flags=flags[:,ind]
    flags = np.squeeze(flags)

    rfTime=np.sort(rfTimeAll-np.amin(SEtAll))
    ind=np.argsort(rfTimeAll-np.amin(SEtAll))

    #These dimensions were hardcoded
    rfAmpAll=rfAmpAll.reshape(1,len(rfAmpAll))
    rfPhaseAll=rfPhaseAll.reshape(1,len(rfPhaseAll))
    rfFreqAll=rfFreqAll.reshape(1,len(rfFreqAll))
    rfCoilAll=rfCoilAll.reshape(1,len(rfCoilAll))

    rfAmp=rfAmpAll[:,ind]
    rfPhase=rfPhaseAll[:,ind]
    rfFreq=rfFreqAll[:,ind]
    rfCoil=rfCoilAll[:,ind]

    # [GzTime,ind]=sort(GzTimeAll-min(SEtAll))
    GzTime=np.array(GzTime)
    ind=np.argsort(GzTimeAll-np.min(SEtAll))
    temp2=GzTimeAll-np.min(SEtAll)
    GzTime=temp2[ind]

    GzAmpAll=GzAmpAll.reshape(1,len(GzAmpAll))
    GzAmp=GzAmpAll[:,ind]

    # [GyTime,ind]=sort(GyTimeAll-np.min(SEtAll))
    GyTime=np.array(GyTime)
    ind=np.argsort(GyTimeAll-np.min(SEtAll))
    temp3=GyTimeAll-np.min(SEtAll)
    GyTime=temp3[ind]

    GyAmpAll=GyAmpAll.reshape(1,len(GyAmpAll))
    GyAmp=GyAmpAll[:,ind]

    # [GxTime,ind]=sort(GxTimeAll-np.min(SEtAll))
    GxTime=np.array(GxTime)
    ind=np.argsort(GxTimeAll-np.min(SEtAll))
    temp4=GxTimeAll-np.min(SEtAll)
    GxTime=temp4[ind]

    GxAmpAll=GxAmpAll.reshape(1,len(GxAmpAll))
    GxAmp=GxAmpAll[:,ind]

    # [ADCTime,ind]=sort(ADCTimeAll-np.min(SEtAll))
    ADCTime=np.array(ADCTime)
    ind=np.argsort(ADCTimeAll-np.min(SEtAll))
    temp5=ADCTimeAll-np.min(SEtAll)
    ADCTime=temp5[ind]

    ADCAll=ADCAll.reshape(1,len(ADCAll))
    ADC=ADCAll[:,ind]
    # [ExtTime,ind]=sort(ExtTimeAll-np.min(SEtAll))
    ExtTime=np.array(ExtTime)
    ind=np.argsort(ExtTimeAll-np.min(SEtAll))
    temp6=ExtTimeAll-np.min(SEtAll)
    ADCTime=temp6[ind]

    ExtAll=ExtAll.reshape(1,len(ExtAll))
    Ext=ExtAll[:,ind]

    rfAmp[0][0] = 0
    rfPhase[0][0] = 0
    rfFreq[0][0] = 0
    GzAmp[0][0] = 0
    GyAmp[0][0] = 0
    GxAmp[0][0] = 0
    ADC[0][0] = 0
    Ext[0][0] = 0
    rfAmp[0][-1] = 0
    rfPhase[0][-1] = 0
    rfFreq[0][-1] = 0
    GzAmp[0][-1] = 0
    GyAmp[0][-1] = 0
    GxAmp[0][-1] = 0
    ADC[0][-1] = 0
    Ext[0][-1] = 0
    dict= {'rfAmp':rfAmp, 'rfPhase':rfPhase, 'rfFreq': rfFreq,'rfCoil':rfCoil,'GzAmp':GzAmp,'GyAmp':GyAmp,'GxAmp':GxAmp,'ADC':ADC,'Ext':Ext,'uts':uts,'ts':ts,'flags':flags}
    return dict
