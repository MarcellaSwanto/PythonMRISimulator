def DoDataTypeConv(VObj,VMag,VCtl,VCoi,VVar,VSig,VSeq):
    import numpy as np
    # When float data is converted to float, data precision is reduced,
    # sometimes may cause wired rounding error, especially may happen in pulse
    # generation section where two different entry time points mistakenly merge to one.
    # To maintain better calculation accuracy, need to convert data to float
    # type explicitly using float().

    #Signal Initialization
    x=np.equal(VSeq['ADCLine'],1)
    y=np.where(x != 0)

    SignalNum = ((y[0]).shape)[0] #=8080
    #np.zeros by default returns float64 type
    VSig['Sx']=np.zeros((1,SignalNum*VObj['TypeNum']*VCoi['RxCoilNum']))
    VSig['Sy']=(np.zeros((1,SignalNum*VObj['TypeNum']*VCoi['RxCoilNum'])))
    VSig['Kz']=(np.zeros((1,SignalNum)))
    VSig['Ky']=(np.zeros((1,SignalNum)))
    VSig['Kx']=(np.zeros((1,SignalNum)))
    VSig['Mz']=np.float32(VSig['Mz'])
    VSig['My']=np.float32(VSig['My'])
    VSig['Mx']=np.float32(VSig['Mx'])
    VSig['Muts']=float(VSig['Muts'])
    VSig['SignalNum']=np.int32(SignalNum)

    #Data Type Conversion
    VObj['Gyro']=float(VObj['Gyro'][0][0])
    VObj['ChemShift']=float(VObj['ChemShift'])
    VObj['Mz']=np.float32(VObj['Mz'])
    VObj['My']=np.float32(VObj['My'])
    VObj['Mx']=np.float32(VObj['Mx'])
    VObj['Rho']=np.float32(VObj['Rho'])
    VObj['T1']=np.float32(VObj['T1'])
    VObj['T2']=np.float32(VObj['T2'])

    VObj['SpinNum']=np.int32(VObj['SpinNum'])
    VObj['TypeNum']=np.int32(VObj['TypeNum'])
    # print(VMag['FRange'].shape)
    VMag['FRange']=VMag['FRange'].astype(float) #astype is needed for multidimensional arrays
    VMag['dB0']=np.float32(VMag['dB0'])
    VMag['dWRnd']=np.float32(VMag['dWRnd'])
    VMag['Gzgrid']=np.float32(VMag['Gzgrid'])
    VMag['Gygrid']=np.float32(VMag['Gygrid'])
    VMag['Gxgrid']=np.float32(VMag['Gxgrid'])

    VCoi['TxCoilmg']=np.float32(VCoi['TxCoilmg'])
    VCoi['TxCoilpe']=np.float32(VCoi['TxCoilpe'])
    VCoi['RxCoilx']=np.float32(VCoi['RxCoilx'])
    VCoi['RxCoily']=np.float32(VCoi['RxCoily'])
    VCoi['TxCoilNum']=np.int32(VCoi['TxCoilNum'])
    VCoi['RxCoilNum']=np.int32(VCoi['RxCoilNum'])
    VCoi['TxCoilDefault']=float(VCoi['TxCoilDefault'])
    VCoi['RxCoilDefault']=float(VCoi['RxCoilDefault'])

    VCtl['CS']=float(VCtl['CS'])
    VCtl['TRNum']=np.int32(VCtl['TRNum'])

    VVar['t']=float(VVar['t'])
    VVar['dt']=float(VVar['dt'])
    VVar['rfAmp']=float(VVar['rfAmp'])
    VVar['rfPhase']=float(VVar['rfPhase'])
    VVar['rfFreq']=float(VVar['rfFreq'])
    VVar['rfCoil']=float(VVar['rfCoil'])
    VVar['rfRef']=float(VVar['rfRef'])
    VVar['GzAmp']=float(VVar['GzAmp'])
    VVar['GyAmp']=float(VVar['GyAmp'])
    VVar['GxAmp']=float(VVar['GxAmp'])
    VVar['ADC']=float(VVar['ADC'])
    VVar['Ext']=float(VVar['Ext'])
    VVar['Kz']=float(VVar['Kz'])
    VVar['Ky']=float(VVar['Ky'])
    VVar['Kx']=float(VVar['Kx'])
    VVar['ObjLoc']=(VVar['ObjLoc']).astype(float)
    VVar['ObjTurnLoc']=(VVar['ObjTurnLoc']).astype(float)
    VVar['ObjMotInd']=float(VVar['ObjMotInd'])
    VVar['ObjAng']=float(VVar['ObjAng'])
    VVar['gpuFetch']=float(VVar['gpuFetch'])
    VVar['utsi']=np.int32(VVar['utsi'])
    VVar['rfi']=np.int32(VVar['rfi'])
    VVar['Gzi']=np.int32(VVar['Gzi'])
    VVar['Gyi']=np.int32(VVar['Gyi'])
    VVar['Gxi']=np.int32(VVar['Gxi'])
    VVar['ADCi']=np.int32(VVar['ADCi'])
    VVar['Exti']=np.int32(VVar['Exti'])
    VVar['SliceCount']=np.int32(1)
    VVar['PhaseCount']=np.int32(1)
    VVar['TRCount']=np.int32(1)

    VSeq['utsLine']=(VSeq['utsLine']).astype(float)
    VSeq['tsLine']=(VSeq['tsLine']).astype(float)
    VSeq['rfAmpLine']=(VSeq['rfAmpLine']).astype(float)
    VSeq['rfPhaseLine']=(VSeq['rfPhaseLine']).astype(float)
    VSeq['rfFreqLine']=(VSeq['rfFreqLine']).astype(float)
    VSeq['rfCoilLine']=(VSeq['rfCoilLine']).astype(float)
    VSeq['GzAmpLine']=(VSeq['GzAmpLine']).astype(float)
    VSeq['GyAmpLine']=(VSeq['GyAmpLine']).astype(float)
    VSeq['GxAmpLine']=(VSeq['GxAmpLine']).astype(float)
    VSeq['ADCLine']=(VSeq['ADCLine']).astype(float)
    VSeq['ExtLine']=(VSeq['ExtLine']).astype(float)
    VSeq['flagsLine']=(VSeq['flagsLine']).astype(float)

    dict = {'VObj' : VObj,'VMag' : VMag,'VCtl' : VCtl, 'VCoi' : VCoi, 'VVar' : VVar, 'VSig' : VSig, 'VSeq' : VSeq}
    return dict
