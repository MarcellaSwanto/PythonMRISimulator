#create a Ext signal pulse starting from tStart
#tStart = Ext signal start time
#Ext = Ext flag
def ExtBit(p, VCtl):
    import numpy as np
    from numpy import array
    from StdBit import StdBit

    tStart = p['tStart']
    Ext = p['Ext']
    Duplicates = np.maximum(1, p['Duplicates'])
    DupSpacing = np.maximum(0, p['DupSpacing'])

    tempdict = StdBit(tStart, tStart+(2*VCtl['MinUpdRate']), Ext)
    Ext = tempdict['Grad']
    ExtTime = tempdict['t']

    dict = {'Ext': Ext, 'ExtTime':ExtTime}
    return dict
