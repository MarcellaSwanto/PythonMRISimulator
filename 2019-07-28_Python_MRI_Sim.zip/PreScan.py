def PreScan(properties):
    import array
    import numpy as np
    import nbimporter

    VCtl ={'TR':10, 'TEAnchor':'Middle', 'MultiTransmit':'off', 'MasterTxCoil':1, 'TE':0.0500,'FOVPhase':0.1600,'FOVFreq':0.2000,'BandWidth':80000,'MinUpdRate':0.000004,'MaxGrad':0.0500,'MaxSlewRate':200,'ResFreq': 101,'RFreq': 0.002,'ResPhase': 80,'RPhase': 0.0025,'SliceNum': 1,'RSlice': 0.006,'FOVSlice': 0.006,'TrajType': 'cartesian','FirstPhNum': 80,'SecondPhNum': 1,'FlipAng': 90,'TEAnchorTime': 0,'SpinNum': 1,'TRNum': 80,'FreqDir': 'A/P','ISO': [55, 46,46],'CS': 0}

    #To get the number of layers, rows, columns for Rho
    temptuple = properties['Rho'].shape
    layer = temptuple[0] #layer
    row = temptuple[1] #row
    column = temptuple[2] #column

    #VObj Virtual Object
    VObj ={'ChemShift':0,'SpinNum' : 1,'TypeNum' : 1,'XDimRes' : 0.002,'YDimRes' : 0.002,'ZDimRes' : 0.002,'XDim' : 90,'YDim' : 108,'ZDim' : 90,'Rho' : properties['Rho'],'T1' : properties['T1'],'T2' : properties['T2'],'T2Star' : properties['T2Star'],'MassDen' : properties['MassDen'], 'Gyro': properties['Gyro']}
    #VMag Virtual Magnetic Field
    VMag ={'FRange': np.ones((layer, row, column)),'dB0' : np.zeros((layer, row, column)),'dWRnd' : np.zeros((layer, row, column, VObj['SpinNum'], VObj['TypeNum'])),'Gzgrid' : np.zeros((layer, row, column)),'Gygrid' : np.zeros((layer, row, column)),'Gxgrid' : np.zeros((layer, row, column))}
    #Gradient Grid
    ISO=VCtl['ISO']

    ###########################################################################
    # Gx,y,z grid are of correct shape, but incorrect values
    # Important notes worth taking into account:
    #Meshgrid on Python operates row by row
    #Whereas Matlab operates column by column
    a1 = np.arange((-ISO[0]+1)*VObj['XDimRes'], (VObj['XDim']-ISO[0])*VObj['XDimRes']+0.002, VObj['XDimRes'])
    a2 = np.arange((-ISO[1]+1)*VObj['YDimRes'], (VObj['YDim']-ISO[1])*VObj['YDimRes']+0.002, VObj['YDimRes'])
    a3 = np.arange((-ISO[2]+1)*VObj['ZDimRes'], (VObj['ZDim']-ISO[2])*VObj['ZDimRes']+0.002, VObj['ZDimRes'])
    #arange is used because some parameters are floats and not ints. Range only takes in integers
    Gxgrid, Gygrid, Gzgrid = np.meshgrid(a1, a3, a2)
    # What we tried:
    # transpos = []
    # for i in range(0, 108):
    #     transpos.append(Gxgrid[:,:,i].transpose())
    # # transposed = Gxgrid.transpose()
    # transpos = np.array(transpos)
    # transpos = transpos.reshape([90,90,108])

    # The scan process parameter for FreqDir is A/P, which corresponds to the
    # axial view. (Anterior-Posterior)
    # The NoFreqAlias, NoPhaseAlias, NoSliceAlias fields of VCtl were not
    # been created.
    VMag['Gxgrid']=Gxgrid
    VMag['Gygrid']=Gygrid
    VMag['Gzgrid']=Gzgrid

    AP1=5
    AP2=105

    LR1 = 6
    LR2 = 86

    SI1 = 45
    SI2 = 48
    FRange = VMag['FRange']

    for i in range(0,SI1):
        for j in range(0, len(VMag['FRange'][1])-1):
            for k in range(0, len(VMag['FRange'][2])-1):
                FRange[i][j][k]=0
    # FRange[np.arange(0, AP1-1,1), :, :]=0
    for i in range(SI2,len(VMag['FRange'][0])):
        for j in range(0, len(VMag['FRange'][1])):
            for k in range(0, len(VMag['FRange'][2])):
                FRange[i][j][k]=0
    # FRange[np.arange(AP2,VObj['XDim']-1,1), :, :]=0

    for i in range(0, len(VMag['FRange'][0])):
        for j in range(0,LR1):
            for k in range(0, len(VMag['FRange'][2])):
                FRange[i][j][k]=0
    # FRange[:, np.arange(0, LR1-1,1) ,:]=0
    for i in range(0, len(VMag['FRange'][0])):
        for j in range(LR2, len(VMag['FRange'][1])):
            for k in range(0, len(VMag['FRange'][2])):
                FRange[i][j][k]=0
    # FRange[:, np.arange(LR2,VObj['XDim']-1,1) ,:]=0

    for i in range(0, len(VMag['FRange'][0])):
        for j in range(0, len(VMag['FRange'][1])):
            for k in range(0,AP1):
                FRange[i][j][k]=0
    # FRange[:, :, np.arange(0,SI1-1,1)]=0
    for i in range(0, len(VMag['FRange'][0])):
        for j in range(0, len(VMag['FRange'][1])):
            for k in range(AP2, len(VMag['FRange'][2])):
                FRange[i][j][k]=0
    # FRange[:, :, np.arange(SI2,VObj['ZDim']-1,1)]=0


    VObj['Mx'] = np.zeros((layer, row, column, VObj['SpinNum'], VObj['TypeNum']))
    VObj['My'] = np.zeros((layer, row, column, VObj['SpinNum'], VObj['TypeNum']))
    VObj['Mz'] = np.zeros((layer, row, column, VObj['SpinNum'], VObj['TypeNum']))

    VObj['Mz']=VObj['Rho']
    #VOb['Mz']  is hardcoded

    #VSig Virtual Signal
    VSig ={'Mx': VObj['Mx'],'My': VObj['My'],'Mz': VObj['Mz'],'Muts' : 0}

     #VCoi Virtual Coils
     # B1Level: linear scale factor for B1. The input B1+ field with magnitude of this number produces nominal flip angle
     # E1Level: linear scale factor for E1. The input E1+ field is scaled by an factor of nominal rf amplitude normalzed by this number
    VCoi ={'TxCoilNum': 1,'RxCoilNum': 1,'TxCoilDefault': 1,'RxCoilDefault': 1,'TxCoilmg': np.ones((layer, row, column)),'TxCoilpe': np.zeros((layer, row, column)),'RxCoilx': np.ones((layer, row, column)),'RxCoily': np.zeros((layer, row, column)),'TxE1x': 0,'TxE1y': 0,'TxE1z': 0,'RxE1x': 0,'RxE1y': 0,'RxE1z': 0}

    # VMot Virtual Motion
    VMot={'t': 0,'ind': 1,'Disp': np.array([[0],[0],[0]]),'Axis': np.array([[1],[0],[0]]),'Ang': 0}

    # VVar Virtual Pulse Packet Initialization
    VVar={'rfAmp': np.zeros((VCoi['TxCoilNum'], 1)),'rfPhase': np.zeros((VCoi['TxCoilNum'], 1)),'rfFreq': np.zeros((VCoi['TxCoilNum'], 1)),'rfCoil': 0,'rfRef': 0,'GzAmp': 0,'GyAmp': 0,'GxAmp': 0,'ADC': 0,'Ext': 0,'t': 0,'dt': 0,'rfi': 0,'Gzi': 0,'Gyi': 0,'Gxi': 0,'ADCi': 0,'Exti': 0,'utsi': 0,'Kz': 0,'Ky': 0,'Kx': 0,'SliceCount': 0,'PhaseCount': 0,'TRCount': 0,'ObjLoc': np.array([[0],[0],[0]]),'ObjTurnLoc': np.array([[0],[0],[0]]),'ObjAng': 0,'ObjMotInd': 0,'gpuFetch': 0}

    dictionary = {'VObj':VObj, 'VMag':VMag, 'VSig':VSig, 'VCoi':VCoi, 'VMot':VMot, 'VVar': VVar, 'VCtl': VCtl}
    return dictionary
