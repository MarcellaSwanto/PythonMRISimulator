def Scan(tempdict1):
    import numpy as np
    from PulseGen import PulseGen
    from DoDataTypeConv import DoDataTypeConv
    from DoPostScan import DoPostScan
    VObj = tempdict1['VObj']
    VMag = tempdict1['VMag']
    VCoi = tempdict1['VCoi']
    VSig = tempdict1['VSig']
    VMot = tempdict1['VMot']
    VVar = tempdict1['VVar']
    VCtl = tempdict1['VCtl']
    #Preserve VObj and VMag
    VTmpObj = VObj
    VTmpMag = VMag

    #Create Exectuing Virtual Structure VOex, VMex
    #VOex.Rho(repmat(VMag.FRange,  [1,1,1,VObj.TypeNum])==0)=[];
    #VOex.T1(repmat(VMag.FRange,[1,1,1,VObj.TypeNum])==0)=[];
    #VOex.T2(repmat(VMag.FRange,[1,1,1,VObj.TypeNum])==0)=[];
    #VOex.Mz(repmat(VMag.FRange,[1,1,1,VObj.SpinNum,VObj.TypeNum])==0)=[];
    #VOex.My(repmat(VMag.FRange,[1,1,1,VObj.SpinNum,VObj.TypeNum])==0)=[];
    #VOex.Mx(repmat(VMag.FRange,[1,1,1,VObj.SpinNum,VObj.TypeNum])==0)=[];

    VOex = VObj
    RhoList = []
    T1List = []
    T2List = []
    MzList = []
    MyList = []
    MxList = []
    #This does the repmat function in python
    x0 = np.tile(VMag['FRange'],[1,1,1,VObj['TypeNum']])
    x = np.squeeze(x0)
    y = np.equal(x,0)

    AP1=5
    AP2=105

    LR1 = 6
    LR2 = 86

    SI1 = 45
    SI2 = 48

    xnew = 0
    for i in range(0,len(y[0])): #Might have to switch around values of SI1, etc if numbers aren't the same
        for j in range(0,len(y[1])):
            for k in range(0,len(y[2])):
                if y[i][j][k] == False:
                    RhoList.append(VOex['Rho'][i][j][k])
                    T1List.append(VOex['T1'][i][j][k])
                    T2List.append(VOex['T2'][i][j][k])


    x0 = np.tile(VMag['FRange'],[1,1,1,VObj['SpinNum'],VObj['TypeNum']])
    x = np.squeeze(x0)
    y = np.equal(x,0)

    for i in range(SI1,SI2): #Might have to switch around values of SI1, etc if numbers aren't the same
        for j in range(LR1,LR2):
            for k in range(AP1,AP2):
                if y[i][j][k] == False:
                    MxList.append(VOex['Mx'][i][j][k])
                    MyList.append(VOex['My'][i][j][k])
                    MzList.append(VOex['Mz'][i][j][k])

    VOex['Rho'] = RhoList
    VOex['T1'] = T1List
    VOex['T2'] = T2List
    VOex['Mz'] = MzList
    VOex['My'] = MyList
    VOex['Mx'] = MxList

    # --------------------------
    VMex=VMag

    VMex_z_List = []
    VMex_y_List = []
    VMex_x_List = []
    dB0_List = []
    dWRnd_List = []
    dWRnd_List1 = []
    x = np.squeeze(VMag['FRange'])
    y = np.equal(x,0)
    for i in range(0,len(y[0])):
        for j in range(0,len(y[1])):
            for k in range(0,len(y[2])):
                if y[i][j][k] == False:
                    VMex_z_List.append(VMex['Gzgrid'][i][j][k])
                    VMex_x_List.append(VMex['Gxgrid'][i][j][k])
                    VMex_y_List.append(VMex['Gygrid'][i][j][k])
                    dB0_List.append(VMex['dB0'][i][j][k])

    x0 = np.tile(VMag['FRange'],[1,1,1,VObj['SpinNum'],VObj['TypeNum']])

    x = np.squeeze(x0)

    y = np.equal(x,0)

    for i in range(0,len(y[0])):
        for j in range(0,len(y[1])):
            for k in range(0,len(y[2])):
                if y[i][j][k] == False:
                    dWRnd_List.append(VMex['dWRnd'][i][j][k])


    y0 = np.isnan(dWRnd_List)
    y = np.squeeze(y0)
    x1 = len(dWRnd_List)

    for i in range(0,x1):
        if y0[i] == True:
            dWRnd_List1.append(0)
        else:
            dWRnd_List1.append(dWRnd_List[i])

    VMex['Gzgrid'] = VMex_z_List
    VMex['Gxgrid'] = VMex_x_List
    VMex['Gygrid'] = VMex_y_List
    VMex['dB0'] = dB0_List
    VMex['dWRnd'] = dWRnd_List1

    rho = np.array(VOex['Rho'])
    t1 = np.array(VOex['T1'])
    t2 = np.array(VOex['T2'])
    mz = np.array(VOex['Mz'])
    my = np.array(VOex['My'])
    mx = np.array(VOex['Mx'])

    VOex['Rho'] = rho.reshape(80,3, 100)
    VOex['T1'] = t1.reshape(80,3,100)
    VOex['T2'] = t2.reshape(80,3,100)
    VOex['Mz'] = mz.reshape(80,3,100)
    VOex['My'] = my.reshape(80,3,100)
    VOex['Mx'] = mx.reshape(80,3,100)

    gz = np.array(VMex['Gzgrid'])
    gx = np.array(VMex['Gxgrid'])
    gy = np.array(VMex['Gygrid'])
    db0 = np.array(VMex['dB0'])
    dwrnd = np.array(VMex['dWRnd'])

    VMex['Gzgrid'] = gz.reshape(80,3, 100)
    VMex['Gxgrid'] = gx.reshape(80,3, 100)
    VMex['Gygrid'] = gy.reshape(80,3, 100)
    VMex['dB0'] = db0.reshape(80,3, 100)
    VMex['dWRnd'] = dwrnd.reshape(80,3, 100)

    #Code to find the size of VOex.Mz
    tempTuple = VOex['Mz'].shape
    row = tempTuple[0]
    col = tempTuple[1]
    layer = tempTuple[2]

    VVar['ObjLoc'] = np.vstack((((col+1)/2)*VOex['XDimRes'],((row+1)/2)*VOex['YDimRes'],((layer+1)/2)*VOex['ZDimRes']))
    VVar['ObjTurnLoc'] = np.vstack((((col+1)/2)*VOex['XDimRes'],((row+1)/2)*VOex['YDimRes'],((layer+1)/2)*VOex['ZDimRes']))

    VOex['MaxMz'] = np.amax(VOex['Mz'])
    VOex['MaxMy'] = np.amax(VOex['My'])
    VOex['MaxMx'] = np.amax(VOex['Mx'])
    VOex['MaxRho'] = np.amax(VOex['Rho'])
    VOex['MaxT1'] = np.amax(VOex['T1'])
    VOex['MaxT2'] = np.amax(VOex['T2'])
    VOex['MaxdWRnd'] = np.amax(VMex['dWRnd'])
    #Spin Execution
    VObj = VOex
    VMag = VMex
    #Scan Process
    tempdict1 = PulseGen(VVar, VCtl, VObj)
    VVar = tempdict1['VVar']
    VCtl = tempdict1['VCtl']
    VSeq = tempdict1['VSeq']

    VCtl['RunMode'] = np.int32(0)
    tempdict1 = DoDataTypeConv(VObj,VMag,VCtl,VCoi,VVar,VSig,VSeq)
    VObj = tempdict1['VObj']
    VMag = tempdict1['VMag']
    VCoi = tempdict1['VCoi']
    VSig = tempdict1['VSig']
    VVar = tempdict1['VVar']
    VCtl = tempdict1['VCtl']

    VCtl['MaxThreadNum'] = 8
    VCtl['ActiveThreadNum'] = np.int32(0)

    #Code to be converted and tested:
    #DoScanAtCPU()
    #DoPostScan()
    #VObj = VTmpObj
    #VMag = VTmpMag
    return
