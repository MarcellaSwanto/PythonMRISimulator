def GxCartesian(p, VObj, VCtl, VVar):
    import numpy as np
    import math
    from StdTrap import StdTrap
    t1Start = p['t1Start']
    t2Middle = p['t2Middle']
    t3Start = p['t3Start']
    tRamp = p['tRamp']
    Gx1Sign = p['Gx1Sign']
    Gx2Sign = p['Gx2Sign']
    Gx3Sign = p['Gx3Sign']
    Duplicates = np.maximum(1, p['Duplicates'])
    DupSpacing = np.maximum(0, p['DupSpacing'])

    #Frequency encoding
    GxAmp = np.divide(np.divide(1,VCtl['FOVFreq']), np.multiply(np.divide(VObj['Gyro'], (2*math.pi)), (1/VCtl['BandWidth'])))
    tHalf = np.divide(1, 2*np.divide(VObj['Gyro'],2*math.pi)*GxAmp*VCtl['RFreq'])
    tempDict = StdTrap(t1Start-tRamp,t1Start+tHalf+tRamp,t1Start,t1Start+tHalf,GxAmp*Gx1Sign,2,2,2)
    GAmp1 = tempDict['Grad']
    GTime1 = tempDict['t']

    tempDict = StdTrap(t2Middle+VCtl['TEAnchorTime']-tHalf-tRamp, t2Middle+VCtl['TEAnchorTime']+tHalf+tRamp,t2Middle+VCtl['TEAnchorTime']-tHalf,t2Middle+VCtl['TEAnchorTime']+tHalf,GxAmp*Gx2Sign,2,2,2)
    GAmp2 = tempDict['Grad']
    GTime2 = tempDict['t']

    tempDict = StdTrap(t3Start-tRamp,t3Start+tHalf+tRamp,t3Start,t3Start+tHalf,GxAmp*Gx3Sign,2,2,2)
    GAmp3 = tempDict['Grad']
    GTime3 = tempDict['t']

    GAmp = GAmp2
    GTime = GTime2

    if Gx1Sign != 0:
        GAmp = np.concatenate((GAmp1, GAmp), axis = None)
        GTime = np.concatenate((GTime1, GTime), axis = None)

    if Gx3Sign != 0:
        GAmp = np.concatenate((GAmp, GAmp3), axis = None)
        GTime = np.concatenate((GTime, GTime3), axis = None)

    GTime, m, n = np.unique(GTime, return_index = True, return_inverse = True)
    GAmp = GAmp[m]
    dict = {'GAmp':GAmp, 'GTime':GTime}
    return dict
