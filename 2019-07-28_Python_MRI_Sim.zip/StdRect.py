#Note - as multiple values need to be outputted, they are outputted as a list
def StdRect(tStart, tEnd, gAmp, step):
    #tStart = start time
    #tEnd = end time
    #step = increment steps
    #gAmp = amplitude
    import numpy as np

    t = np.linspace(tStart, tEnd, step)
    Grad = gAmp*(np.ones(t.shape))

    dict = {'t':t, 'Grad':Grad}
    return dict
