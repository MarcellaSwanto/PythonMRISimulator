
def ADCCartesian(p, VCtl, VObj):
    import numpy as np
    import math
    from StdTrap import StdTrap

    tMiddle = p['tMiddle']
    Duplicates = np.maximum(1, p['Duplicates'])
    DupSpacing = np.maximum(0,p['DupSpacing'])

    #acquisition lobs
    GxAmp = np.divide(np.divide(1,VCtl['FOVFreq']), np.multiply(np.divide(VObj['Gyro'], (2*math.pi)), (1/VCtl['BandWidth'])))
    tHalf = np.divide(1, 2*np.divide(VObj['Gyro'],2*math.pi)*GxAmp*VCtl['RFreq'])

    tempDict = StdTrap(tMiddle+VCtl['TEAnchorTime']-tHalf-VCtl['MinUpdRate'],tMiddle+VCtl['TEAnchorTime']+tHalf+VCtl['MinUpdRate'],tMiddle+VCtl['TEAnchorTime']-tHalf,tMiddle+VCtl['TEAnchorTime']+tHalf,1,2,VCtl['ResFreq'],2)
    GAmp1 = tempDict['Grad']
    GTime1 = tempDict['t']

    GAmp = np.concatenate((GAmp1), axis=None)
    GTime = np.concatenate((GTime1), axis=None)

    GTime, m, n = np.unique(GTime, return_index = True, return_inverse = True)
    GAmp = GAmp[m]

    #Create Duplicates
    outdict ={'GAmp':GAmp, 'GTime':GTime}

    return outdict
