def rfSinc(p, VObj):
    #Create a sinc rf pulse starting from tStart and ending at tEnd
    #tStart = rf start time
    #tEnd = rf end time
    #FA = rf actual flip angle
    #dt = rf sample time
    #TBP = time-bandwidth product
    #Apod = apodization flag
    #rfPhase = rf rfPhase#rfFreq = rf off-res freq
    import numpy as np
    import math
    from DoB1Scaling import DoB1Scaling

    tStart = p['tStart']
    tEnd = p['tEnd']
    FA = p['FA']
    dt = p['dt']
    rfPhase = p['rfPhase']
    rfFreq = p['rfFreq']
    rfCoil = p['CoilID']
    TBP = p['TBP']
    Apod = p['Apod']
    Duplicates = np.maximum(1, p['Duplicates'])
    DupSpacing = np.maximum(0, p['DupSpacing'])

    a = 0 #This is asusming that the case for apodization is 'Non'

    rfTime = np.linspace(tStart, tEnd, np.ceil((tEnd-tStart)/dt)+1)
    rfTime = rfTime-((tEnd-tStart)/2)-tStart
    t0 = (tEnd-tStart)/TBP


    rfAmp = np.divide((t0*np.sin(np.divide(math.pi*rfTime,t0))),(math.pi*rfTime))#s*((1-a)+a*math.cos(np.divide(math.pi*rfTime,(TBP*t0)))
    templist = rfAmp
    templist=templist[~np.isnan(templist)]
    for i in range(0, len(rfAmp)):
        if np.isnan(rfAmp[i]):
            rfAmp[i] = np.amax(templist)
    rfAmp[0] = 0
    rfAmp[-1] = 0
    rfAmp = np.multiply(DoB1Scaling(rfAmp, dt, FA, VObj),rfAmp) # B1 Scaling
    rfTime = rfTime+((tEnd-tStart)/2)+tStart
    #The code below is to work out the size of rfTime
    temptuple = rfTime.shape #This stores a tuple containing the size of rfTime
    # print(temptuple)
    t1 = temptuple[0]


    rfPhase = (rfPhase)*np.ones(t1)
    rfFreq = (rfFreq)*np.ones(t1)
    rfCoil = (rfCoil)*np.ones(t1)
    rfPhase[0] = 0
    rfPhase[-1] = 0
    rfFreq[0] = 0
    rfFreq[-1] = 0
    #In the original code, the create duplicates section was removed.
    dict = {'rfAmp':rfAmp, 'rfPhase':rfPhase, 'rfFreq':rfFreq, 'rfCoil':rfCoil, 'rfTime':rfTime}
    return dict
