def DoB1Scaling(PulSeg, dt, ActFA, VObj):
    import numpy as np
    import math

    #The code below is used the find the size of PulSeg
    tempTuple = PulSeg.shape
    t1 = tempTuple[0]

    flag = np.zeros((t1))
    ind = np.diff(np.absolute(PulSeg))
    for i in range(0, len(ind)):
        if np.isnan(ind[i]):
            ind[i] = 0

    #Code for : flag(find(ind<0)+1)=1;
    #ind<0
    x = np.less(ind,0)
    #find(ind<0)+1
    y = x.ravel().nonzero()
    newlist = []
    #Forming a list with the indices in the ind that are greater than 0+1
    for i in range(0,len(y[0])):
        newlist.append(y[0][i]+1)
    #looping through the array with the true or false values
    newlist2 = []
    x = 0 #Counter for 'for' loop
    for i in range(0,len(flag)):
        for j in range(0,len(newlist)):
            if i == newlist[j]:
                newlist2.append(1)
            else:
                x=x+1
        if x == len(newlist):
            newlist2.append(flag[i])
        x = 0

    flag = newlist2

    #flag(ind>=0)=1;
    x = np.greater_equal(ind,0)

    newlist = []
    #looping through the array with the true or false values
    for i in range(0,len(flag)):
        if i<50:
            if x[i] == True:
                newlist.append(1)
            else:
                newlist.append(flag[i])
        else:
            newlist.append(flag[i])
    flag = newlist
    rfGain = ((ActFA/185)*math.pi)/(VObj['Gyro'][0][0]*np.sum(np.multiply(PulSeg,flag))*dt)
    return rfGain
