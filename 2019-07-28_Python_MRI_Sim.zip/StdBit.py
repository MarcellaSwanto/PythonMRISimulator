from StdRect import StdRect

def StdBit(tStart, tEnd, gAmp):
    #Create a minimum signal pulse starting from tStart
    #tStart = signal pulse start time
    #tEnd = signal pulse end time
    a = StdRect(tStart, tEnd, gAmp, 3) #Signal bit
    Grad = a['Grad']
    t = a['t']
    Grad[0] = 0
    Grad[len(Grad)-1] = 0
    
    dict = {'t':t, 'Grad':Grad}
    return dict
