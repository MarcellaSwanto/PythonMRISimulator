function PreScan()

global VObj;
global VCtl;
global VMag;
global VCoi;
global VVar;
global VSig;
global VMot;

global VMmg;
global VMco;
global VMgd;

VCtl=[]; % update VCtl
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%All of the below variables are hardcoded for the scanning parameters
%mentioned before for the PSD_GRE3D file. Code doesn't work without it... 
VCtl.TR = 10;
VCtl.TEAnchor = 'Middle';
VCtl.MultiTransmit = 'off';
VCtl.MasterTxCoil = 1;
VCtl.TE = 0.0500;
VCtl.FOVPhase = 0.1600;
VCtl.FOVFreq = 0.2000;
VCtl.BandWidth = 80000;
VCtl.MinUpdRate = 0.000004;
VCtl.MaxGrad = 0.0500;
VCtl.MaxSlewRate = 200;

% FOV & resolution
% Cartesian
VCtl.ResFreq = 101;
VCtl.RFreq=0.002;
VCtl.ResPhase = 80; % guarantee even number of Ky sample points for Ky = 0
VCtl.RPhase=0.0025;
VCtl.SliceNum = 1; % guarantee even number of Kz sample points for Kz = 0
VCtl.RSlice=0.006;
VCtl.FOVSlice=0.006;
VCtl.TrajType='cartesian';
VCtl.FirstPhNum = 80;
VCtl.SecondPhNum = 1;
    %These are the calculations
%   VCtl.ResFreq = VCtl.ResFreq + ~mod(VCtl.ResFreq,2) % guarantee odd number of Kx sample points for sampling echo peak when Kx = 0
%   VCtl.RFreq=VCtl.FOVFreq/(VCtl.ResFreq - 1);
%   VCtl.ResPhase = VCtl.ResPhase - mod(VCtl.ResPhase,2); % guarantee even number of Ky sample points for Ky = 0
%   VCtl.RPhase=VCtl.FOVPhase/VCtl.ResPhase;
%   VCtl.SliceNum = max(1,VCtl.SliceNum - mod(VCtl.SliceNum,2)); % guarantee even number of Kz sample points for Kz = 0
%   VCtl.RSlice=VCtl.SliceThick;
%   VCtl.FOVSlice=VCtl.SliceNum*VCtl.SliceThick;
%   VCtl.TrajType='cartesian';
%   VCtl.FirstPhNum = VCtl.ResPhase;
%   VCtl.SecondPhNum = VCtl.SliceNum;

% Others
VCtl.FlipAng=90; % degree
VCtl.TEAnchorTime=0;
%Simuh.ISO = each dimension (Simuh.ISO's) *2 - 2
VCtl.ISO=[46 55 46];
VCtl.CS=0;%VObj.ChemShift*VCtl.B0;
VObj.SpinNum=1; % Controllable Spin number in each voxel
                                % Transfer VCtl to VObj, should have better
                                % way to do this ??


VCtl.TRNum=VCtl.FirstPhNum*VCtl.SecondPhNum;
VCtl.FreqDir='A/P';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% VMag Virtual Magnetic Field
Mxdims=size(VObj.Rho);

VMag=struct(                                      ...
           'FRange',    ones([Mxdims(1), Mxdims(2), Mxdims(3)]), ...
           'dB0',       zeros([Mxdims(1), Mxdims(2), Mxdims(3)]),    ...
           'dWRnd',     zeros([Mxdims(1), Mxdims(2), Mxdims(3), VObj.SpinNum, VObj.TypeNum]), ...
           'Gzgrid',    zeros([Mxdims(1), Mxdims(2), Mxdims(3)]), ...
           'Gygrid',    zeros([Mxdims(1), Mxdims(2), Mxdims(3)]), ...
           'Gxgrid',    zeros([Mxdims(1), Mxdims(2), Mxdims(3)]) ...
          );

% Gradient Grid             

    [Gxgrid,Gygrid,Gzgrid]=meshgrid((-VCtl.ISO(1)+1)*VObj.XDimRes:VObj.XDimRes:(VObj.XDim-VCtl.ISO(1))*VObj.XDimRes,...
                                    (-VCtl.ISO(2)+1)*VObj.YDimRes:VObj.YDimRes:(VObj.YDim-VCtl.ISO(2))*VObj.YDimRes,...
                                    (-VCtl.ISO(3)+1)*VObj.ZDimRes:VObj.ZDimRes:(VObj.ZDim-VCtl.ISO(3))*VObj.ZDimRes);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%These values were hardcoded. They are used to find the field of view
AP1=5; 
AP2=105;

LR1 = 6;
LR2 = 86;

SI1 = 45;
SI2 = 48;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%The scan process parameter for FreqDir is A/P, which corresponds to the
%Axial view. (Anterior-Posterior) Also have L/R and S/I (Superior/Inferior)
%The NoFreqAlias, NoPhaseAlias, NoSliceAlias fields of VCtl have not yet
%been created.
     VMag.Gxgrid=Gygrid;
     VMag.Gygrid=Gxgrid;
     VMag.Gzgrid=Gzgrid;
            
     VMag.FRange(1:AP1-1,:,:)=0;
     VMag.FRange(AP2:end,:,:)=0;
     
     %The four lines 
     VMag.FRange(:,1:LR1-1,:)=0;
     VMag.FRange(:,LR2:end,:)=0;
     
     VMag.FRange(:,:,1:SI1-1)=0;
     VMag.FRange(:,:,SI2:end)=0;

%% VObj Virtual Object
VObj.Mx=zeros([Mxdims(1), Mxdims(2), Mxdims(3), VObj.SpinNum, VObj.TypeNum]);
VObj.My=zeros([Mxdims(1), Mxdims(2), Mxdims(3), VObj.SpinNum, VObj.TypeNum]);
VObj.Mz=zeros([Mxdims(1), Mxdims(2), Mxdims(3), VObj.SpinNum, VObj.TypeNum]);

VObj.Mz= VObj.Rho;
%% VSig Virtual Signal
VSig.Mx=VObj.Mx;
VSig.My=VObj.My;
VSig.Mz=VObj.Mz;
VSig.Muts=0;

%% VCoi Virtual Coils
% B1Level: linear scale factor for B1. The input B1+ field with magnitude of this number produces nominal flip angle
% E1Level: linear scale factor for E1. The input E1+ field is scaled by an factor of nominal rf amplitude normalzed by this number
VCoi=struct( ...
            'TxCoilNum', 1, ...
            'RxCoilNum', 1, ...
            'TxCoilDefault',1,... % use default Tx Coil
            'RxCoilDefault',1,... % use default Rx Coil
            'TxCoilmg',ones([Mxdims(1), Mxdims(2), Mxdims(3)]), ...
            'TxCoilpe',zeros([Mxdims(1), Mxdims(2), Mxdims(3)]), ...
            'RxCoilx',ones([Mxdims(1), Mxdims(2), Mxdims(3)]), ...
            'RxCoily',zeros([Mxdims(1), Mxdims(2), Mxdims(3)]), ...
            'TxE1x',0,...
            'TxE1y',0,...
            'TxE1z',0,...
            'RxE1x',0,...
            'RxE1y',0,...
            'RxE1z',0 ...
            );

    %% VMot Virtual Motion
VMot=struct( ...
            't', 0, ...
            'ind', 1, ...
            'Disp', [0;0;0], ...
            'Axis', [1;0;0], ...
            'Ang', 0  ...          
            );
    
%% VVar Virtual Pulse Packet Initialization
VVar=struct(                          ...
    'rfAmp',        zeros(VCoi.TxCoilNum, 1), ...
    'rfPhase',      zeros(VCoi.TxCoilNum, 1), ...
    'rfFreq',       zeros(VCoi.TxCoilNum, 1), ...
    'rfCoil',       0, ...
    'rfRef',        0,              ...
    'GzAmp',        0,              ...
    'GyAmp',        0,              ...
    'GxAmp',        0,              ...
    'ADC',          0,              ...
    'Ext',          0,              ...
    't',            0,              ...
    'dt',           0,              ...
    'rfi',          0,              ...
    'Gzi',          0,              ...
    'Gyi',          0,              ...
    'Gxi',          0,              ...
    'ADCi',         0,              ...
    'Exti',         0,              ...
    'utsi',         0,              ...
    'Kz',           0,              ...
    'Ky',           0,              ...
    'Kx',           0,              ...
    'SliceCount',   0,              ...
    'PhaseCount',   0,              ...
    'TRCount',      0,              ...
    'ObjLoc',       [0;0;0],        ...  % Object location
    'ObjTurnLoc',   [0;0;0],        ...  % Object turning point location
    'ObjAng',       0,              ...  % Object rotating angle
    'ObjMotInd',    0,              ...  % Object motion section index
    'gpuFetch',     0               ...  % Flag for fetching GPU data at extended process 
    );

end



