function SaveOutput()

global VImg;
global VCtl;
global VSig;

OutputDir='C:\Users\krith\Downloads\mritopython-master-V10\mritopython-master-V10\output';

fields = {'Mx','My','Mz','Muts','SignalNum'};
VSig = rmfield(VSig,fields);
%Naming the image with date and time
c = clock();
imageName = strcat('\output\Scanned_Image','_',num2str(c(3)),'_',num2str(c(2)),'_',num2str(c(1)),'_',num2str(c(4)),'_',num2str(c(5)),'_',num2str(c(6)),'.png');

figure;
imgrecon = imagesc(squeeze(sum(VImg.Mag,4)));
colormap(gray(256))
saveas(gcf, [pwd imageName])

%uncomment the below line of code if you want to save a .mat file
% save([OutputDir filesep 'Series1'], 'VCtl', 'VSig', 'VImg'); 

end